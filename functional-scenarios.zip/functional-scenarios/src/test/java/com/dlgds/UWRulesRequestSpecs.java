package com.dlgds;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        strict = true,
        plugin = {"pretty"},
        tags = {"@UWRules"},
        features = {"classpath:features/UWRules/"},
        format = {"html:build/reports/html/tests/", "junit:build/test-results/test/cucumber.xml"})
public class UWRulesRequestSpecs {
}
