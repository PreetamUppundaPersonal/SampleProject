package com.dlgds;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class ContextConfig {

    private static final Config conf = ConfigFactory.load();

    public static String serviceEndpoint() {
        return conf.getString("application.service-endpoint");
    }

    public static int intervalBetweenRequests() {
        return conf.getInt("application.interval-between-requests");
    }
}
