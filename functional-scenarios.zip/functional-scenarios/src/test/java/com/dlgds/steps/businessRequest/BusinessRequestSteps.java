package com.dlgds.steps.businessRequest;

import com.dlgds.serviceElements.ResponseElements;
import com.dlgds.steps.AbstractSteps;
import com.dlgds.utils.XMLUtil;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;

public class BusinessRequestSteps extends AbstractSteps {

    XMLUtil xmlUtil = new XMLUtil();
    ResponseElements responseElements = new ResponseElements();
    List<String> notesReferences;
    List<String> notesDescription;
    List<String> xSBreakDownCodes;
    List<String> xSBreakDownAmounts;
    List<String> xSBreakDownDescriptions;
    List<String> xSBreakDownReasons;
    List<String> xSBreakDownPrns;
    List<String> endorsementTitles;
    List<String> endorsementCodes;
    List<String> endorsementPrns;
    List<String> endorsementValues;

    @Given("^A (.+) request for (.+) vehicle with (.+), (.+) yrs ncd, (\\d+) conviction, (\\d+) claim and (.+) xs$")
    public void aNewBusinessRequest(String requestType, String usage, String numberOfDrivers, String ncd, int convictions, int claims, String volXs) throws Throwable {
        xmlUtil.baseXml(requestType, numberOfDrivers, ncd, convictions, claims, volXs);
    }

    @When("^request is sent and response received$")
    public void requestIsSentAndResponseReceived() throws Throwable {
        xmlUtil.sendRequestAndGetResponse();
    }

    @Given("^Request XML '(.+)'$")
    public void requestXML(String requestXmlFile) throws Throwable {
        givenRequest(requestXmlFile);
    }

    @When("^a system calls the scoring service$")
    public void aSystemCallsTheScoringService() throws Throwable {
        whenResponse();
    }

    @Then("^validate (.+) response for (.+) request with (.+), vol xs (\\d+), AD comp xs (\\d+), F&T comp xs (\\d+) and Drivers allowed (.+)$")
    public void ValidateResponseForRequest(String errorCount, String requestType, String numberOfDrivers, int volExcess, int adExcess, int ftExcess, String driversAllowed) throws Throwable {
        //Assert Status code
        assertStatusCode(200);

        //Assert content type - XML
        assertContentType();

        //Assert Schema
        assertSchema();

        switch (requestType) {
            case "New Business":
                assertResponse("TranResultTranName", "QuoteDetail");
                assertResponse("ProcessingIndicators_ProcessType", "02");
                assertNotNull("Intermediary_BusinessSourceText");
                if (!errorCount.toLowerCase().contentEquals("error"))
                    validatePremiumIsWithinRange();
                break;
            case "MTA":
                assertResponse("TranResultTranName", "MTA");
                assertResponse("ProcessingIndicators_ProcessType", "05");
                if (!errorCount.toLowerCase().contentEquals("error"))
                    validatePremiumIsWithinRange();
                break;
            case "Cancellation":
                assertResponse("TranResultTranName", "CancelAdd");
                assertResponse("ProcessingIndicators_ProcessType", "22");
                assertNotNull("Intermediary_BusinessSourceText");
                break;
            default:
                break;
        }

        if (errorCount.toLowerCase().contentEquals("error")) {
            assertResponse("TranResultErrorCount", "1");
            assertResponse("SchemeResultErrorCount", "1");
        } else {
            assertResponse("TranResultErrorCount", "0");
            assertResponse("SchemeResultErrorCount", "0");
        }

        assertResponse("PolMessageType", "TransactionResponse");
        assertResponse("PolMessageVersion", "1");
        assertResponse("TranResultCompleted", "Y");
        assertResponse("SchemeResultCompleted", "Y");
        assertResponse("SchemeResultRef", "1");
        assertResponse("PolDataType", "Output");
        assertResponse("Intermediary_Code", "A10603");
        assertResponse("Cover_Code", "C");
        assertResponse("Cover_PermittedDrivers", driversAllowed);
        assertResponse("Cover_Period", "A");
        assertResponse("Cover_VolXsAllowed", volExcess + "");

        List<String> responsELements = Arrays.asList(
                "ProposerPolicyholder_Surname",
                "ProposerPolicyholder_TitleText",
                "ProposerPolicyholder_ForenameInitial1",
                "ProposerPolicyholder_DateOfBirth",
                "ProposerPolicyholder_AddressLine1",
                "ProposerPolicyholder_PostCodeFull"
        );
        assertNotNull(responsELements);

        //assert valid policy
        validateValidPolicy();

        //assert valid notes
        notesReferences = response.xmlPath().getList(PD_MTA_RSP + "Notes.Notes_Reference.@Val");
        notesDescription = response.xmlPath().getList(PD_MTA_RSP + "Notes.Notes_Description.@Val");
        if (!requestType.toLowerCase().contentEquals("cancellation"))
            validateValidNotes(numberOfDrivers, volExcess, adExcess, ftExcess);
    }

    public void validateValidNotes(String numberOfDrivers, int volXs, int adExcess, int ftExcess) {
        if (adExcess < 100)
            adExcess = 100;
        if (ftExcess < 150)
            ftExcess = 150;
        iterateAndValidateNotes("VXSS-" + volXs, "Voluntary Excess...................................................(£)");
        iterateAndValidateNotes("CWX1-10", "Windscreen Repair Excess...........................................(£)");
        iterateAndValidateNotes("WINR-75", "Windscreen Replacement Excess......................................(£)");
        iterateAndValidateNotes("CAX1-" + adExcess, "Compulsory Accidental Damage Excess for Proposer...................(£)");

        if (numberOfDrivers.contains("1 driver")) {
            iterateAndValidateNotes("W8X1-" + ftExcess, "Compulsory Fire and Theft Excess for Proposer......................(£)");
        } else if (numberOfDrivers.contains("2 drivers")) {
            iterateAndValidateNotes("CAX2-" + adExcess, "Compulsory Accidental Damage Excess for Driver 2...................(£)");
            iterateAndValidateNotes("W8X1-" + ftExcess, "Compulsory Fire and Theft Excess for Proposer......................(£)");
            iterateAndValidateNotes("W8X2-" + ftExcess, "Compulsory Fire and Theft Excess for Driver 2......................(£)");
        } else if (numberOfDrivers.contains("3 drivers")) {
            iterateAndValidateNotes("CAX2-" + adExcess, "Compulsory Accidental Damage Excess for Driver 2...................(£)");
            iterateAndValidateNotes("CAX3-" + adExcess, "Compulsory Accidental Damage Excess for Driver 3...................(£)");
            iterateAndValidateNotes("W8X1-" + ftExcess, "Compulsory Fire and Theft Excess for Proposer......................(£)");
            iterateAndValidateNotes("W8X2-" + ftExcess, "Compulsory Fire and Theft Excess for Driver 2......................(£)");
            iterateAndValidateNotes("W8X3-" + ftExcess, "Compulsory Fire and Theft Excess for Driver 3......................(£)");
        }
    }

    @Then("^validate the response for element value (.+)$")
    public void validateTheResponseForElementValue(String dataString) {
        String[] resElementValue = dataString.split(";-");
        for (String elementsValue : resElementValue) {
            String[] nodevalue = elementsValue.trim().split(":");
            assertResponse(nodevalue[0], nodevalue[1]);
        }
    }

    @Then("^the response body contains a valid (.+) Vehicle with (.+) years ncd$")
    public void theResponseBodyContainsAValidVehicleWith7YearsNcd(String isBusinessUse, String ncdYears) {
        List<String[]> responsELementsValues = Arrays.asList(
                new String[]{"Uses_UsedByDriver1Ind", "Y"},
                new String[]{"Ncd_ClaimedYears", ncdYears},
                new String[]{"Ncd_ClaimedDiscountType", "2"},
                new String[]{"Vehicle_PostCodeFull", "BR1 1DS"},
                new String[]{"Vehicle_RegNo", "BU01CDL"},
                new String[]{"Vehicle_Model", "17503401"}
        );
        assertResponse(responsELementsValues);

        if (isBusinessUse.contains("Business Use")) {
            String code = isBusinessUse.split(" ")[2];
            assertResponse("Uses_AbiCode", code);
        } else {
            String code = isBusinessUse.split(" ")[1];
            assertResponse("Uses_AbiCode", code);
        }
        assertNotNull("Policy_QuoteAuthorisationRef");
        assertNotNull("PolicyCommunicationData_TextVariable1");
    }

    @Then("^the response body contains a valid Calculated Result and compulsory xs (.+)$")
    public void theResponseBodyContainsAValidCalculatedResultWithCompulsoryXs(String compulsoryExcess) {
        assertResponse("CalculatedResult_GuaranteedQuoteInd", "Y");
        assertResponse("CalculatedResult_IptPct", "12.0");
        assertResponse("CalculatedResult_CompulsoryXs", compulsoryExcess);
        assertNotNull("CalculatedResult_PremiumExclIpt");
        assertNotNull("CalculatedResult_PremiumInclIpt");
    }

    @Then("^the response body contains a valid (.+) Result$")
    public void theResponseBodyContainsAValidDeclinedResult(String outCome) {
        if (outCome.toLowerCase().contentEquals("declined"))
            assertResponse("DeclineResult", "Apologies, we can't provide a quote based on your details.");
        else {
            assertResponse("TranResultErrorCount", "0");
            assertResponse("SchemeResultErrorCount", "0");
        }
    }

    @Then("^the response body contains (\\d+) status, (.+) and (.+) error message$")
    public void theResponseBodyContainsAnErrorMessage(int statusCode, String statusMessage, String errorMessage) {
        //Assert Status code
        assertStatusCode(statusCode);

        assertResponseSubString(statusMessage);
        assertResponseSubString(errorMessage);
    }

    @Then("^the response body contains 200 status, TransactionResult (.+) and SchemeResult (.+)$")
    public void theResponseBodyContains(String schemeResult, String errorCount) {
        //Assert Status code
        assertStatusCode(200);

        assertResponse("TranResultErrorCount", schemeResult);
        assertResponse("SchemeResultErrorCount", errorCount);
    }

    @Then("^the response body contains (.+) Communication Data$")
    public void theResponseBodyContainsAValidCommunicationData(String validErrored) {
        assertResponse("CommunicationData_Code", "02");
        if (validErrored.contentEquals("valid")) {
            assertResponse("CommunicationData_Description", "True");
        } else {
            assertResponse("CommunicationData_Description", "False");
        }
    }

    @Then("^the response body (.+) a (.+) endorsement$")
    public void theResponseBody101Endorsement(String endorsement, int code) {
        endorsementCodes = response.xmlPath().getList(PD_MTA_RSP + "EndorsementResult.EndorsementResult_Code.@Val");
        endorsementTitles = response.xmlPath().getList(PD_MTA_RSP + "EndorsementResult.EndorsementResult_Title.@Val");
        endorsementPrns = response.xmlPath().getList(PD_MTA_RSP + "EndorsementResult.EndorsementResult_DriverPrn.@Val");
        endorsementValues = response.xmlPath().getList(PD_MTA_RSP + "EndorsementResult.EndorsementResult_Value.@Val");
        if (endorsement.contentEquals("contains")) {
            switch (code) {
                case 101:
                    iterateAndValidateEndorsement("Policy Excludes Driving Other Cars", "101", "0");
                    break;
                case 111:
                    iterateAndValidateEndorsement("Mobile Caravans : Exclude insurance of contents", "111", "0");
                    break;
                case 140:
                    iterateAndValidateEndorsement("Benefit Endorsement – No Claims Discount Protection", "140", "0");
                    break;
                case 196:
                    iterateAndValidateEndorsement("Negate Section D - Windscreen", "196", "0");
                    break;
            }
        } else {
            validateNoEndorsement(code + "");
        }
    }

    @Then("^Validate breakdown result$")
    public void validateBreakdownResult() {
        validateQuoteBreakdown();
        xSBreakDownCodes = response.xmlPath().getList(PD_MTA_RSP + "ExcessBreakdownResult.ExcessBreakdownResult_SectionCode.@Val");
        xSBreakDownAmounts = response.xmlPath().getList(PD_MTA_RSP + "ExcessBreakdownResult.ExcessBreakdownResult_Amount.@Val");
        xSBreakDownDescriptions = response.xmlPath().getList(PD_MTA_RSP + "ExcessBreakdownResult.ExcessBreakdownResult_Description.@Val");
        xSBreakDownReasons = response.xmlPath().getList(PD_MTA_RSP + "ExcessBreakdownResult.ExcessBreakdownResult_Reason.@Val");
        xSBreakDownPrns = response.xmlPath().getList(PD_MTA_RSP + "ExcessBreakdownResult.ExcessBreakdownResult_DriverPrn.@Val");
        iterateAndValidateBreakDown("Accidental Damage Fire And Thef", "3", "", "038", "0");
        iterateAndValidateBreakDown("Windscreen Repair Excess", "51", "10", "039", "0");
        iterateAndValidateBreakDown("Windscreen Replacement Excess", "5", "75", "039", "0");
        iterateAndValidateBreakDown("Fire and Theft", "2", "", "034", "0");
        iterateAndValidateBreakDown("Accidental Damage", "1", "", "018", "0");
    }

    public void validateQuoteBreakdown() {
        assertResponse("QuoteBreakdownResult_Code", "203");
        assertNotNull("QuoteBreakdownResult_Amount");
        assertResponse("QuoteBreakdownResult_Description", "Final Premium");
        assertNotNull("QuoteBreakdownResult_RunningTotal");
    }

    public void validateValidPolicy() {
        assertResponse("PolicyCommunicationData_SubjectCode", "62");
        assertResponse("PolicyCommunicationData_FunctionCode", "1");
        assertResponse("PolicyCommunicationData_ReferenceCodelist", "01");
        assertResponse("PolicyCommunicationData_ReferenceCodelistValue", "AQN");
        assertNotNull("Policy_QuoteAuthorisationRef");
        assertNotNull("PolicyCommunicationData_TextVariable1");
    }

    @And("^Set request xml element attribute value (.+)$")
    public void setRequestXmlElementAttributeValue(String dataString) throws Throwable {
        if (!dataString.contentEquals("none"))
            xmlUtil.setAttributeForElements(dataString);
    }

    @And("^Modify request nodes (.+)$")
    public void requestHasAdditonalNodes(String dataString) throws Throwable {
        if (!dataString.contentEquals("none"))
            xmlUtil.modifyNodes(dataString);
    }

    public void assertResponse(List<String[]> elementAndValues) {
        for (int i = 0; i < elementAndValues.size(); i++)
            response.then().assertThat().body(responseElements.getXPath(elementAndValues.get(i)[0]), is(elementAndValues.get(i)[1]));
    }

    public void assertNotNull(List<String> elements) {
        for (int i = 0; i < elements.size(); i++)
            response.then().assertThat().body(responseElements.getXPath(elements.get(i)), notNullValue());
    }

    public void assertNotNull(String element) {
        response.then().assertThat().body(responseElements.getXPath(element), notNullValue());
    }

    public void assertResponse(String elementName, String value) {
        response.then().assertThat().body(responseElements.getXPath(elementName), is(value));
    }

    public void iterateAndValidateNotes(String reference, String description) {
        boolean passed = false;
        for (int i = 0; i < notesDescription.size(); i++) {
            if (notesDescription.get(i).contentEquals(description)) {
                Assert.assertTrue("Expected:" + reference + " Actual:" + notesReferences.get(i), notesReferences.get(i).contentEquals(reference));
                passed = true;
            }
        }
        if (!passed)
            Assert.fail("Reference:" + reference + " with  Description:" + description + "  not found");
    }

    public void iterateAndValidateBreakDown(String description, String sectionCode, String amount, String reason, String prn) {
        boolean passed = false;
        for (int i = 0; i < xSBreakDownDescriptions.size(); i++) {
            if (xSBreakDownDescriptions.get(i).contentEquals(description)) {
                Assert.assertTrue("Expected:" + sectionCode + " Actual:" + xSBreakDownCodes.get(i), xSBreakDownCodes.get(i).contentEquals(sectionCode));
                Assert.assertTrue("Expected:" + amount + " Actual:" + xSBreakDownAmounts.get(i), xSBreakDownAmounts.get(i).contentEquals(amount) || !xSBreakDownAmounts.get(i).isEmpty());
                Assert.assertTrue("Expected:" + reason + " Actual:" + xSBreakDownReasons.get(i), xSBreakDownReasons.get(i).contentEquals(reason));
                Assert.assertTrue("Expected:" + prn + " Actual:" + xSBreakDownPrns.get(i), xSBreakDownPrns.get(i).contentEquals(prn) || !xSBreakDownPrns.get(i).isEmpty());
                passed = true;
            }
        }
        if (!passed)
            Assert.fail("Breakdown:" + description + "  not found");
    }

    public void iterateAndValidateEndorsement(String title, String code, String value) {
        boolean passed = false;
        for (int i = 0; i < endorsementTitles.size(); i++) {
            if (endorsementTitles.get(i).contentEquals(title)) {
                Assert.assertTrue("Expected:" + code + " Actual:" + endorsementCodes.get(i), endorsementCodes.get(i).contentEquals(code));
                Assert.assertTrue("Expected: Not Empty Actual:" + endorsementPrns.get(i), endorsementPrns.get(i).contentEquals("0") || !endorsementPrns.get(i).isEmpty());
                Assert.assertTrue("Expected:" + value + " Actual:" + endorsementValues.get(i), endorsementValues.get(i).contentEquals(value) || !endorsementValues.get(i).isEmpty());
                passed = true;
            }
        }
        if (!passed)
            Assert.fail("Endorsement:" + title + "  not found");
    }

    public void validateNoEndorsement(String code) {
        for (int i = 0; i < endorsementCodes.size(); i++) {
            Assert.assertFalse("Expected: null Actual:" + endorsementCodes.get(i), endorsementCodes.get(i).contentEquals(code));
        }
    }

    public void assertResponseSubString(String value) {
        response.then().assertThat().body(containsString(value));
    }

    @Then("^validate the premium (.+)$")
    public void validateThePremium(String premium) throws Throwable {
        assertResponse("CalculatedResult_PremiumInclIpt", premium);
    }

    @Then("^validate additional premium (.+)$")
    public void validateAdditionalPremium(String premium) throws Throwable {
        assertResponse("CalculatedResult_AdjustmentPremiumInclIpt", premium);
    }

    @Then("^validate positive additional premium$")
    public void validatePositiveAdditionalPremium() throws Throwable {
        Double additionalPremium = response.xmlPath().getDouble(PD_MTA_RSP + "CalculatedResult.CalculatedResult_PremiumInclIpt.@Val");
        Assert.assertTrue("Additonal premium is not positive", additionalPremium > 0);
    }

    @Then("^validate premium on removing PNCD$")
    public void validatePremiumOnRemovingPNCD() throws Throwable {
        Double originalPremium = response.xmlPath().getDouble(PD_MTA_RSP + "CalculatedResult.CalculatedResult_OriginalPremium.@Val");
        Double newPremium = response.xmlPath().getDouble(PD_MTA_RSP + "CalculatedResult.CalculatedResult_NewRiskPremium.@Val");
        Double additionalPremium = response.xmlPath().getDouble(PD_MTA_RSP + "CalculatedResult.CalculatedResult_AdjustmentPremiumExclIpt.@Val");
        Assert.assertTrue(Math.round((originalPremium / 1.15) * 100D) / 100D == newPremium);
        Assert.assertTrue("Additonal premium is not negative", additionalPremium < 0);
    }

    @Then("^validate premium is within range$")
    public void validatePremiumIsWithinRange() throws Throwable {
        Double premium = response.xmlPath().getDouble(PD_MTA_RSP + "CalculatedResult.CalculatedResult_PremiumInclIpt.@Val");
        Assert.assertTrue("premium is not between £150 & £6000", premium > 150 && premium < 6000);
    }
}
