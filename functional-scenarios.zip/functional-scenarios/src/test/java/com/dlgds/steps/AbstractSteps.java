package com.dlgds.steps;

import com.dlgds.ContextConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.codec.Charsets;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import static io.restassured.RestAssured.given;
import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;

public class AbstractSteps {

    public static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final String PD_MTA_RSP = "PolMessage.SchemeResult.PolData.";
    protected final HashMap<String, String> XmlElementPath = new HashMap();
    private static final String XSD_SCHEMA = "/cdl_private_car_response_schema.xsd";
    public DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    private RequestSpecification request;
    protected static Response response;

    protected void givenRequest(String resource) throws IOException {
        request = givenRequest(resourceToString(resource), ContentType.XML);
    }

    public RequestSpecification givenRequest(String content, ContentType contentType) {
        request = given().body(content).contentType(contentType).accept(ContentType.XML);
        System.out.println(content);
        return request;
    }

    protected void whenResponse() {
        response = request.when().post(ContextConfig.serviceEndpoint());
        response.then().log().all();
        try {
            Thread.sleep(ContextConfig.intervalBetweenRequests());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    protected void assertStatusCode(int statusCode) {
        response.then().assertThat().statusCode(statusCode);
    }

    protected void assertContentType() {
        response.then().assertThat().contentType(ContentType.XML);
    }

    protected void assertSchema() throws IOException {
        response.then().assertThat().body(matchesXsd(resourceToString(XSD_SCHEMA)));
    }

    protected String resourceToString(String name) throws IOException {
        return IOUtils.resourceToString(name, Charsets.UTF_8);
    }

    public String getXPath(String elementName) {
        return XmlElementPath.get(elementName);
    }
}
