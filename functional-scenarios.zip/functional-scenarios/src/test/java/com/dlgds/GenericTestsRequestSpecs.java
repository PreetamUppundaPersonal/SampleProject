package com.dlgds;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        strict = true,
        plugin = {"pretty"},
        tags = {"@cdl"},
        features = {"classpath:features/GenericTests.feature"},
        format = {"html:build/reports/html/tests/", "junit:build/test-results/test/cucumber.xml"})
public class GenericTestsRequestSpecs {
}
