package com.dlgds.serviceElements;

import com.dlgds.steps.AbstractSteps;

public class ResponseElements extends AbstractSteps {

    public ResponseElements() {
        XmlElementPath.put("PolMessageType", "PolMessage.@Type");
        XmlElementPath.put("PolMessageVersion", "PolMessage.@Version");
        XmlElementPath.put("TranResultCompleted", "PolMessage.TranResult.@Completed");
        XmlElementPath.put("TranResultErrorCount", "PolMessage.TranResult.@ErrorCount");
        XmlElementPath.put("TranResultTranName", "PolMessage.TranResult.@TranName");

        XmlElementPath.put("SchemeResultCompleted", "PolMessage.SchemeResult.@Completed");
        XmlElementPath.put("SchemeResultErrorCount", "PolMessage.SchemeResult.@ErrorCount");
        XmlElementPath.put("SchemeResultRef", "PolMessage.SchemeResult.@Ref");
        XmlElementPath.put("PolDataType", PD_MTA_RSP + "@Type");
        XmlElementPath.put("ProcessingIndicators_ProcessType", PD_MTA_RSP + "ProcessingIndicators.ProcessingIndicators_ProcessType.@Val");
        XmlElementPath.put("Intermediary_Code", PD_MTA_RSP + "Intermediary.Intermediary_Code.@Val");
        XmlElementPath.put("Intermediary_BusinessSourceText", PD_MTA_RSP + "Intermediary.Intermediary_BusinessSourceText.@Val");
        XmlElementPath.put("ProposerPolicyholder_Surname", PD_MTA_RSP + "ProposerPolicyholder.ProposerPolicyholder_Surname.@Val");
        XmlElementPath.put("ProposerPolicyholder_TitleText", PD_MTA_RSP + "ProposerPolicyholder.ProposerPolicyholder_TitleText.@Val");
        XmlElementPath.put("ProposerPolicyholder_ForenameInitial1", PD_MTA_RSP + "ProposerPolicyholder.ProposerPolicyholder_ForenameInitial1.@Val");
        XmlElementPath.put("ProposerPolicyholder_DateOfBirth", PD_MTA_RSP + "ProposerPolicyholder.ProposerPolicyholder_DateOfBirth.@Val");
        XmlElementPath.put("ProposerPolicyholder_AddressLine1", PD_MTA_RSP + "ProposerPolicyholder.ProposerPolicyholder_AddressLine1.@Val");
        XmlElementPath.put("ProposerPolicyholder_AddressLine2", "/PolMessage/SchemeResult/PolData/ProposerPolicyholder/ProposerPolicyholder_AddressLine2");
        XmlElementPath.put("ProposerPolicyholder_AddressLine3", "/PolMessage/SchemeResult/PolData/ProposerPolicyholder/ProposerPolicyholder_AddressLine3");
        XmlElementPath.put("ProposerPolicyholder_PostCodeFull", PD_MTA_RSP + "ProposerPolicyholder.ProposerPolicyholder_PostCodeFull.@Val");
        XmlElementPath.put("Cover_Code", PD_MTA_RSP + "Cover.Cover_Code.@Val");
        XmlElementPath.put("Cover_PermittedDrivers", PD_MTA_RSP + "Cover.Cover_PermittedDrivers.@Val");
        XmlElementPath.put("Cover_VolXsAllowed", PD_MTA_RSP + "Cover.Cover_VolXsAllowed.@Val");
        XmlElementPath.put("Cover_Period", PD_MTA_RSP + "Cover.Cover_Period.@Val");
        XmlElementPath.put("Policy_QuoteAuthorisationRef", PD_MTA_RSP + "Policy.Policy_QuoteAuthorisationRef.@Val");
        XmlElementPath.put("PolicyCommunicationData_SubjectCode", PD_MTA_RSP + "Policy.PolicyCommunicationData.PolicyCommunicationData_SubjectCode.@Val");
        XmlElementPath.put("PolicyCommunicationData_FunctionCode", PD_MTA_RSP + "Policy.PolicyCommunicationData.PolicyCommunicationData_FunctionCode.@Val");
        XmlElementPath.put("PolicyCommunicationData_ReferenceCodelist", PD_MTA_RSP + "Policy.PolicyCommunicationData.PolicyCommunicationData_ReferenceCodelist.@Val");
        XmlElementPath.put("PolicyCommunicationData_ReferenceCodelistValue", PD_MTA_RSP + "Policy.PolicyCommunicationData.PolicyCommunicationData_ReferenceCodelistValue.@Val");
        XmlElementPath.put("PolicyCommunicationData_TextVariable1", PD_MTA_RSP + "Policy.PolicyCommunicationData.PolicyCommunicationData_TextVariable1.@Val");
        XmlElementPath.put("Uses_AbiCode", PD_MTA_RSP + "Vehicle.Uses.Uses_AbiCode.@Val");
        XmlElementPath.put("Uses_UsedByDriver1Ind", PD_MTA_RSP + "Vehicle.Uses.Uses_UsedByDriver1Ind.@Val");
        XmlElementPath.put("Uses_UsedByDriver2Ind", "/PolMessage/SchemeResult/PolData/Vehicle/Uses/Uses_UsedByDriver2Ind");
        XmlElementPath.put("Uses_UsedByDriver3Ind", "/PolMessage/SchemeResult/PolData/Vehicle/Uses/Uses_UsedByDriver3Ind");
        XmlElementPath.put("Vehicle_PostCodeFull", PD_MTA_RSP + "Vehicle.Vehicle_PostCodeFull.@Val");
        XmlElementPath.put("Vehicle_RegNo", PD_MTA_RSP + "Vehicle.Vehicle_RegNo.@Val");
        XmlElementPath.put("Vehicle_Model", PD_MTA_RSP + "Vehicle.Vehicle_Model.@Val");
        XmlElementPath.put("Ncd_ClaimedYears", PD_MTA_RSP + "Vehicle.Ncd.Ncd_ClaimedYears.@Val");
        XmlElementPath.put("Ncd_ClaimedDiscountType", PD_MTA_RSP + "Vehicle.Ncd.Ncd_ClaimedDiscountType.@Val");
        XmlElementPath.put("CalculatedResult_OriginalPremium", PD_MTA_RSP + "CalculatedResult.CalculatedResult_OriginalPremium.@Val");
        XmlElementPath.put("CalculatedResult_GuaranteedQuoteInd", PD_MTA_RSP + "CalculatedResult.CalculatedResult_GuaranteedQuoteInd.@Val");
        XmlElementPath.put("CalculatedResult_PremiumExclIpt", PD_MTA_RSP + "CalculatedResult.CalculatedResult_PremiumExclIpt.@Val");
        XmlElementPath.put("CalculatedResult_PremiumInclIpt", PD_MTA_RSP + "CalculatedResult.CalculatedResult_PremiumInclIpt.@Val");
        XmlElementPath.put("CalculatedResult_NewRiskPremium", PD_MTA_RSP + "CalculatedResult.CalculatedResult_NewRiskPremium.@Val");
        XmlElementPath.put("CalculatedResult_IptPct", PD_MTA_RSP + "CalculatedResult.CalculatedResult_IptPct.@Val");
        XmlElementPath.put("CalculatedResult_CompulsoryXs", PD_MTA_RSP + "CalculatedResult.CalculatedResult_CompulsoryXs.@Val");
        XmlElementPath.put("CalculatedResult_AdjustmentPremiumExclIpt", PD_MTA_RSP + "CalculatedResult.CalculatedResult_AdjustmentPremiumExclIpt.@Val");
        XmlElementPath.put("CalculatedResult_AdjustmentPremiumInclIpt", PD_MTA_RSP + "CalculatedResult.CalculatedResult_AdjustmentPremiumInclIpt.@Val");
        XmlElementPath.put("CommunicationData_Code", PD_MTA_RSP + "CommunicationData.CommunicationData_Code.@Val");
        XmlElementPath.put("CommunicationData_Description", PD_MTA_RSP + "CommunicationData.CommunicationData_Description.@Val");
        XmlElementPath.put("QuoteBreakdownResult_Code", PD_MTA_RSP + "QuoteBreakdownResult.QuoteBreakdownResult_Code.@Val");
        XmlElementPath.put("QuoteBreakdownResult_Amount", PD_MTA_RSP + "QuoteBreakdownResult.QuoteBreakdownResult_Amount.@Val");
        XmlElementPath.put("QuoteBreakdownResult_Description", PD_MTA_RSP + "QuoteBreakdownResult.QuoteBreakdownResult_Description.@Val");
        XmlElementPath.put("QuoteBreakdownResult_RunningTotal", PD_MTA_RSP + "QuoteBreakdownResult.QuoteBreakdownResult_RunningTotal.@Val");
        XmlElementPath.put("DeclineResult", PD_MTA_RSP + "DeclineResult.DeclineResult_Text.@Val");
        XmlElementPath.put("ErrorMessage", "error.attributes.entry.value");
    }
}
