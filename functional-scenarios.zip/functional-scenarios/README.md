DLG DS Scoring - Functional Specs
---

## Local env

```bash
./gradlew clean test --debug
```

## Remote env

```bash
env "BASE_URL=https://dev-routing.dlgds.co.uk" ./gradlew clean test --debug
env "BASE_URL=https://cdl-routing.dlgds.co.uk" ./gradlew clean test --debug
```

## TODO

1. More complex checks and validations

## Links

- http://www.baeldung.com/cucumber-spring-integration
- https://github.com/rest-assured/rest-assured/wiki/Usage
- https://github.com/angiejones/restassured-with-cucumber-demo

## Ignore tests
To ignore the tests annotated with @ignore, add the environment variable:
`cucumber.options=--tags ~@ignore` 

This is useful when creating new tests and you don't want to run all tests everytime you're 
adjusting the new test.
