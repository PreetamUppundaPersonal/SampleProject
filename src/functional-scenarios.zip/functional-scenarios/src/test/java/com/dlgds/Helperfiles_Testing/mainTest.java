package com.dlgds.Helperfiles_Testing;

import com.dlgds.ContextConfig;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;

import static io.restassured.RestAssured.given;

/**
 * Created by preetam on 11/09/2018.
 */
public class mainTest {
    public static void main(String[] Args) throws Throwable {
        mainTest test = new mainTest();
        try {
            File inputFile = new File("/Users/preetam/Tech/Automation/functional-scenarios/Helperfiles_Testing/cdl_private_car_request_schema.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            Node rootElement = doc.getDocumentElement();
//            System.out.println("Root element :" + rootElement.getNodeName());
//            System.out.println("----------------------------");

            Node driver = doc.getElementsByTagName("Driver").item(0);

            Element newNode = doc.createElement("MedicalCondition");
            driver.insertBefore(newNode, doc.getElementsByTagName("Driver_MedicalConditionInd").item(0).getNextSibling());

            Node mc = doc.getElementsByTagName("MedicalCondition").item(0);
            Element mcCode = doc.createElement("MedicalCondition_Code");
            test.createAttributeNode(doc, mcCode, "Val", "V11");
            mc.appendChild(mcCode);

            Element mcDVL = doc.createElement("MedicalCondition_DVLAAdvisedInd");
            test.createAttributeNode(doc, mcDVL, "Val", "V12");
            mc.appendChild(mcDVL);

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            // Output to console for testing

            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void setAttribute(Node element, String attributeName, String attributeValue){
        NamedNodeMap attribute = element.getAttributes();
        Node nodeAttribute = attribute.getNamedItem(attributeName);
        nodeAttribute.setTextContent(attributeValue);
    }

    public void createAttributeNode(Document doc, Element element, String attributeName, String attributeValue){
        Attr attr = doc.createAttribute(attributeName);
        attr.setValue(attributeValue);
        element.setAttributeNode(attr);
    }

    public void setAttributeOfAChild(Node parentNode, String elementName, String attributeName, String attributeValue){
        NodeList childNodes = parentNode.getChildNodes();
        for(int i=0; i < childNodes.getLength(); i++){
            if (childNodes.item(i).getNodeName().equals(elementName)){
                setAttribute(childNodes.item(i), attributeName, attributeValue);
                break;
            }
        }
    }

    public void cloneAndAppendAfter(Node nodeToClone){
        Node newNode = nodeToClone.cloneNode(true);
        nodeToClone.getParentNode().insertBefore(newNode, nodeToClone.getNextSibling());
    }

    public Node getChildNode(Node parentNode, String elementName) {
        NodeList childNodes = parentNode.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            if (childNodes.item(i).getNodeName().equals(elementName)) {
                return childNodes.item(i);
            }
        }
        return null;
    }

    public void addChildAfterExistingChild(Document doc, String newElementName, String existingElement, String attributeName, String attributeValue){
        Element childToAdd = doc.createElement(newElementName);

        Node existingChild = doc.getElementsByTagName(existingElement).item(doc.getElementsByTagName(existingElement).getLength() - 1);
        Node parentNode = existingChild.getParentNode();

        parentNode.insertBefore(childToAdd, existingChild);

        Attr attr = doc.createAttribute(attributeName);
        attr.setValue(attributeValue);
        childToAdd.setAttributeNode(attr);
    }

    public void addChildAfterExistingChild(Document doc, String newElementName, String existingElement){
        Element childToAdd = doc.createElement(newElementName);

        Node existingChild = doc.getElementsByTagName(existingElement).item(doc.getElementsByTagName(existingElement).getLength() - 1);
        Node parentNode = existingChild.getParentNode();

        parentNode.insertBefore(childToAdd, existingChild.getNextSibling());
    }

    public void addChildAfterExistingChild(Document doc, Node parentNode, String newElementName, String existingElement, String attributeName, String attributeValue){
        Element childToAdd = doc.createElement(newElementName);

        Node existingChild = doc.getElementsByTagName(existingElement).item(doc.getElementsByTagName(existingElement).getLength() - 1);

        parentNode.insertBefore(childToAdd, existingChild);

        Attr attr = doc.createAttribute(attributeName);
        attr.setValue(attributeValue);
        childToAdd.setAttributeNode(attr);
    }

    public void addChildAfterExistingChild(Document doc, Node parentNode, String newElementName, String existingElement){
        Element childToAdd = doc.createElement(newElementName);

        Node existingChild = doc.getElementsByTagName(existingElement).item(doc.getElementsByTagName(existingElement).getLength() - 1);

        parentNode.insertBefore(childToAdd, existingChild.getNextSibling());
    }

    public void addChildToEmptyNode(Document doc, String newElementName, Node parentNode, String attributeName, String attributeValue){
        Element childToAdd = doc.createElement(newElementName);
        Attr attr = doc.createAttribute(attributeName);
        attr.setValue(attributeValue);
        childToAdd.setAttributeNode(attr);
        parentNode.appendChild(childToAdd);
    }

    public void addChildToEmptyNode(Document doc, String newElementName, Node parentNode){
        Element childToAdd = doc.createElement(newElementName);
        parentNode.appendChild(childToAdd);
    }

    public void removeNode(Node node) {
        while (node.getFirstChild() != null) {
            node.removeChild(node.getFirstChild());
        }
        node.getParentNode().removeChild(node);
    }

//    public RequestSpecification givenRequestXml(String description, String content, ContentType contentType) throws Throwable {
//        request = given().body(content).contentType(contentType).accept(ContentType.XML);
////        request.then().log().all();
//        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
//                new FileOutputStream("D:\\AutomationProj\\functional-scenarios\\src\\test\\java\\XMLs\\" + description + "_Request.txt"), "utf-8"))) {
//            writer.write(content);
//        }
//        System.out.println(content);
//        return request;
//    }

//    protected void whenResponseXml(String description) throws Throwable {
//        response = request.when().post(ContextConfig.serviceEndpoint());
//        response.then().log().all();
//        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
//                new FileOutputStream("D:\\AutomationProj\\functional-scenarios\\src\\test\\java\\XMLs\\" + description + "_Response.txt"), "utf-8"))) {
//            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//            DocumentBuilder builder;
//            try {
//                builder = factory.newDocumentBuilder();
//                Document doc = builder.parse(new InputSource(new StringReader(response.getBody().asString())));
//                Transformer tform = TransformerFactory.newInstance().newTransformer();
//                tform.setOutputProperty(OutputKeys.INDENT, "yes");
//                tform.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
//                tform.transform(new DOMSource(doc), new StreamResult(writer));
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            try {
//                Thread.sleep(50);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//    }
}
