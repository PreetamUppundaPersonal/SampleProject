package com.dlgds.utils;

import com.dlgds.steps.AbstractSteps;
import io.restassured.http.ContentType;
import org.junit.Assert;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.StringWriter;
import java.time.Clock;
import java.time.LocalDate;


public class XMLUtil extends AbstractSteps {
    String requesXmlBody;
    static Document doc;

    public void baseXml(String requestType, String numberOfDrivers, String ncd, int convictions, int claims, String volXs) throws Throwable {
        doc = getXmlForDriver(requestType, numberOfDrivers, convictions, claims);
        String eventDate = LocalDate.now(Clock.systemUTC()).plusDays(1).format(dtf);
        String policyStartDate;
        String policyEndDate;

        switch (requestType.toLowerCase()) {
            case "new business":
                policyStartDate = LocalDate.now(Clock.systemUTC()).plusDays(1).format(dtf);
                policyEndDate = LocalDate.now(Clock.systemUTC()).plusMonths(12).format(dtf);

                setAttribute(doc.getElementsByTagName("Transaction").item(0), "EffectiveDate", policyStartDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveStartDate").item(0), "Val", policyStartDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveEndDate").item(0), "Val", policyEndDate);

                setAttribute(doc.getElementsByTagName("Ncd_ClaimedYears").item(0), "Val", ncd);
                setAttribute(doc.getElementsByTagName("Cover_VolXsAmt").item(0), "Val", volXs);
                break;
            case "mta":
                policyStartDate = LocalDate.now(Clock.systemUTC()).minusMonths(1).format(dtf);
                policyEndDate = LocalDate.now(Clock.systemUTC()).plusMonths(11).minusDays(1).format(dtf);

                setAttribute(doc.getElementsByTagName("Transaction").item(0), "EffectiveDate", eventDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveStartDate").item(0), "Val", policyStartDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveStartDate").item(1), "Val", policyStartDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveEndDate").item(0), "Val", policyEndDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveEndDate").item(1), "Val", policyEndDate);
                setAttribute(doc.getElementsByTagName("PolicyEvent_Date").item(0), "Val", eventDate);
                setAttribute(doc.getElementsByTagName("PolicyEvent_Date").item(1), "Val", eventDate);

                setAttribute(doc.getElementsByTagName("Ncd_ClaimedYears").item(1), "Val", ncd);
                setAttribute(doc.getElementsByTagName("Cover_VolXsAmt").item(1), "Val", volXs);
                break;
            case "cancellation":
                policyStartDate = LocalDate.now(Clock.systemUTC()).minusMonths(1).format(dtf);
                policyEndDate = LocalDate.now(Clock.systemUTC()).plusMonths(11).minusDays(1).format(dtf);

                setAttribute(doc.getElementsByTagName("Transaction").item(0), "EffectiveDate", eventDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveStartDate").item(0), "Val", policyStartDate);
                setAttribute(doc.getElementsByTagName("Policy_EffectiveEndDate").item(0), "Val", policyEndDate);
                setAttribute(doc.getElementsByTagName("PolicyEvent_Date").item(0), "Val", eventDate);

                setAttribute(doc.getElementsByTagName("Ncd_ClaimedYears").item(0), "Val", ncd);
                setAttribute(doc.getElementsByTagName("Cover_VolXsAmt").item(0), "Val", volXs);
                break;
        }
    }

    public void sendRequestAndGetResponse() throws Throwable {
        //convert doc to string
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(doc), new StreamResult(writer));
        requesXmlBody = writer.getBuffer().toString();
        givenRequest(requesXmlBody, ContentType.XML);
        whenResponse();
    }

    public void setAttributeForElements(String dataString) throws Throwable {
        String[] elementsToModify = dataString.split(";-");
        for (String elementsValue : elementsToModify) {
            String[] nodevalue = elementsValue.trim().split(":");
            if (nodevalue[2].toLowerCase().contentEquals("empty"))
                nodevalue[2] = "";
            try {
                setAttribute(doc.getElementsByTagName(nodevalue[0]).item(Integer.parseInt(nodevalue[1]) - 1), "Val", nodevalue[2]);
            } catch (Exception parEx) {
//                System.out.println(parEx.toString());
                setAttribute(doc.getElementsByTagName(nodevalue[0]).item(0), nodevalue[1], nodevalue[2]);
            }
        }
    }

    public void modifyNodes(String dataString) throws Throwable {
        String[] elementsToModify = dataString.split(";-");
        for (String elements : elementsToModify) {
            String[] elementActions = elements.trim().split(" ");
            switch (elementActions[0].toLowerCase()) {
                //Input String format
                //Add NodeToadd ParentToAddUnder:index+1 AddAfterSibling:index+1
                case "add":
                    String[] parent_Instance_Add = elementActions[2].split(":");
                    String[] sibling_Instance_add = elementActions[3].split(":");
                    Element nodeToAdd = doc.createElement(elementActions[1]);
                    Node parentNode_Add = doc.getElementsByTagName(parent_Instance_Add[0]).item(Integer.parseInt(parent_Instance_Add[1]) - 1);
                    NodeList siblingList = parentNode_Add.getChildNodes();
                    Node siblingNode_Add = null;
                    int counter1 = 0;
                    for (int i = 0; i < siblingList.getLength(); i++) {
                        if (siblingList.item(i).getNodeName().equals(sibling_Instance_add[0])) {
                            counter1++;
                            if (counter1 == Integer.parseInt(sibling_Instance_add[1])) {
                                siblingNode_Add = siblingList.item(i);
                                break;
                            }
                        }
                    }
                    parentNode_Add.insertBefore(nodeToAdd, siblingNode_Add.getNextSibling());
                    break;
                //Input String format
                //Create attributeNode:value parent:index+1
                case "create":
                    String[] elementValue = elementActions[1].split(":");
                    Element newNode = doc.createElement(elementValue[0]);
                    String[] parent_Instance_Create = elementActions[2].split(":");
                    Node parentNode = doc.getElementsByTagName(parent_Instance_Create[0]).item(Integer.parseInt(parent_Instance_Create[1]) - 1);
                    createAttributeNode(doc, newNode, "Val", elementValue[1]);
                    parentNode.appendChild(newNode);
                    break;
                //Input String format
                //Clone nodeToClone:index+1 ParentToAppendUnder:index+1 afterSibling:index+1
                case "clone":
                    String[] clone_Instance = elementActions[1].split(":");
                    String[] parent_Instance_Clone = elementActions[2].split(":");
                    String[] sibling_Instance_Clone = elementActions[3].split(":");
                    Node nodeToClone = doc.getElementsByTagName(clone_Instance[0]).item(Integer.parseInt(clone_Instance[1]) - 1);
                    Node parentNode_Clone = doc.getElementsByTagName(parent_Instance_Clone[0]).item(Integer.parseInt(parent_Instance_Clone[1]) - 1);
                    NodeList siblingNodeList = parentNode_Clone.getChildNodes();
                    Node siblingNode_Clone = null;
                    int counter2 = 0;
                    for (int i = 0; i < siblingNodeList.getLength(); i++) {
                        if (siblingNodeList.item(i).getNodeName().equals(sibling_Instance_Clone[0])) {
                            counter2++;
                            if (counter2 == Integer.parseInt(sibling_Instance_Clone[1])) {
                                siblingNode_Clone = siblingNodeList.item(i);
                                break;
                            }
                        }
                    }
                    cloneAndAppendAfter(nodeToClone, parentNode_Clone, siblingNode_Clone);
                    break;
                //Input String format
                //Remove nodeToRemove:index+1 parent:index+1
                case "remove":
                    String[] parent_Instance_Remove = elementActions[2].split(":");
                    String[] Node_Instance_Remove = elementActions[1].split(":");
                    Node parentNode_Remove = doc.getElementsByTagName(parent_Instance_Remove[0]).item(Integer.parseInt(parent_Instance_Remove[1]) - 1);
                    NodeList nodeList = parentNode_Remove.getChildNodes();
                    Node nodeToRemove = null;
                    int counter3 = 0;
                    for (int i = 0; i < nodeList.getLength(); i++) {
                        if (nodeList.item(i).getNodeName().equals(Node_Instance_Remove[0])) {
                            counter3++;
                            if (counter3 == Integer.parseInt(Node_Instance_Remove[1])) {
                                nodeToRemove = nodeList.item(i);
                                break;
                            }
                        }
                    }
                    removeNode(nodeToRemove);
                    break;
            }
        }
    }

    public Document getXmlForDriver(String requestType, String numberOfDrivers, int convictions, int claims) throws Throwable {
        File inputFile = null;
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            switch (requestType.toLowerCase()) {
                case "new business":
                    inputFile = new File("src/test/resources/cdl_private_car_NewBusiness_request_template.xml");
                    doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();

                    //Remove additonal claims
                    NodeList claimNodes = doc.getElementsByTagName("Claim");
                    NodeList claimIndNodes = doc.getElementsByTagName("Driver_ClaimsInd");
                    for (int i = claimNodes.getLength() - 1; i >= claims; i--) {
                        removeNode(claimNodes.item(i));
                        setAttribute(claimIndNodes.item(i), "Val", "N");
                    }

                    //Remove additonal convictions
                    NodeList convictionNodes = doc.getElementsByTagName("Conviction");
                    NodeList convictionIndNodes = doc.getElementsByTagName("Driver_ConvictionsInd");
                    for (int i = convictionNodes.getLength() - 1; i >= convictions; i--) {
                        removeNode(convictionNodes.item(i));
                        setAttribute(convictionIndNodes.item(i), "Val", "N");
                    }

                    //Remove additonal drivers
                    int noOfDrivers = Integer.parseInt(numberOfDrivers.split(" ")[0]);

                    NodeList driverNodes = doc.getElementsByTagName("Driver");
                    for (int i = driverNodes.getLength() - 1; i > noOfDrivers - 1; i--) {
                        removeNode(driverNodes.item(i));
                        removeNode(doc.getElementsByTagName("Uses_UsedByDriver" + (i + 1) + "Ind").item(0));
                    }
                    break;

                case "mta":
                    inputFile = new File("src/test/resources/cdl_private_car_MTA_request_template.xml");
                    doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();

                    //Remove additonal claims
                    NodeList claimNodes_MTA = doc.getElementsByTagName("Claim");
                    NodeList claimIndNodes_MTA = doc.getElementsByTagName("Driver_ClaimsInd");
                    for (int i = claimNodes_MTA.getLength() - 1; i >= claims + 2; i--) {
                        removeNode(claimNodes_MTA.item(i));
                        setAttribute(claimIndNodes_MTA.item(i), "Val", "N");
                    }

                    //Remove additonal convictions
                    NodeList convictionNodes_MTA = doc.getElementsByTagName("Conviction");
                    NodeList convictionIndNodes_MTA = doc.getElementsByTagName("Driver_ConvictionsInd");
                    for (int i = convictionNodes_MTA.getLength() - 1; i >= convictions + 2; i--) {
                        removeNode(convictionNodes_MTA.item(i));
                        setAttribute(convictionIndNodes_MTA.item(i), "Val", "N");
                    }

                    //Remove additonal drivers
                    int noOfDrivers_MTA = Integer.parseInt(numberOfDrivers.split(" ")[0]);

                    NodeList driverNodes_MTA = doc.getElementsByTagName("Driver");
                    for (int i = driverNodes_MTA.getLength() - 1; i > noOfDrivers_MTA + 1; i--) {
                        removeNode(driverNodes_MTA.item(i));
                        if (i == 4)
                            removeNode(doc.getElementsByTagName("Uses_UsedByDriver" + (i - 1) + "Ind").item(0));
                        else
                            removeNode(doc.getElementsByTagName("Uses_UsedByDriver" + (i - 1) + "Ind").item(1));
                    }
                    break;

                case "cancellation":
                    inputFile = new File("src/test/resources/cdl_private_car_Cancel_request_template.xml");
                    doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();

                    //Remove additonal claims
                    NodeList claimNodes_cancel = doc.getElementsByTagName("Claim");
                    NodeList claimIndNodes_cancel = doc.getElementsByTagName("Driver_ClaimsInd");
                    for (int i = claimNodes_cancel.getLength() - 1; i >= claims; i--) {
                        removeNode(claimNodes_cancel.item(i));
                        setAttribute(claimIndNodes_cancel.item(i), "Val", "N");
                    }

                    //Remove additonal convictions
                    NodeList convictionNodes_cancel = doc.getElementsByTagName("Conviction");
                    NodeList convictionIndNodes_cancel = doc.getElementsByTagName("Driver_ConvictionsInd");
                    for (int i = convictionNodes_cancel.getLength() - 1; i >= convictions; i--) {
                        removeNode(convictionNodes_cancel.item(i));
                        setAttribute(convictionIndNodes_cancel.item(i), "Val", "N");
                    }

                    //Remove additonal drivers
                    int noOfDrivers_cancel = Integer.parseInt(numberOfDrivers.split(" ")[0]);

                    NodeList driverNodes_cancel = doc.getElementsByTagName("Driver");
                    for (int i = driverNodes_cancel.getLength() - 1; i > noOfDrivers_cancel - 1; i--) {
                        removeNode(driverNodes_cancel.item(i));
                        removeNode(doc.getElementsByTagName("Uses_UsedByDriver" + (i + 1) + "Ind").item(0));
                    }
                    break;

            }
        } catch (Exception ex) {
            Assert.fail(ex.toString());
        }
        return doc;
    }

    public void removeNode(Node node) {
        while (node.getFirstChild() != null) {
            node.removeChild(node.getFirstChild());
        }
        Node prevElem = node.getPreviousSibling();
        if (prevElem != null &&
                prevElem.getNodeType() == Node.TEXT_NODE &&
                prevElem.getNodeValue().trim().length() == 0) {
            node.getParentNode().removeChild(prevElem);
        }
        node.getParentNode().removeChild(node);
    }

    public void setAttribute(Node element, String attributeName, String attributeValue) {
        NamedNodeMap attribute = element.getAttributes();
        Node nodeAttribute = attribute.getNamedItem(attributeName);
        nodeAttribute.setTextContent(attributeValue);
    }

    public void setAttributeOfNodes(String tagName, int skip, String attributeName, String attributeValue) {
        NodeList listOfNodes = doc.getElementsByTagName(tagName);
        for (int i = skip; i < listOfNodes.getLength(); i++) {
            setAttribute(listOfNodes.item(i), attributeName, attributeValue);
        }
    }

    public void createAttributeNode(Document doc, Element element, String attributeName, String attributeValue) {
        Attr attr = doc.createAttribute(attributeName);
        attr.setValue(attributeValue);
        element.setAttributeNode(attr);
    }

    public void cloneAndAppendAfter(Node nodeToClone, Node addToNode, Node placeAfter) {
        Node newNode = nodeToClone.cloneNode(true);

        addToNode.insertBefore(newNode, placeAfter.getNextSibling());
    }
}