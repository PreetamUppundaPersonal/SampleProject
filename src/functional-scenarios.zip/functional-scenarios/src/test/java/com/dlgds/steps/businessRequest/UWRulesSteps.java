package com.dlgds.steps.businessRequest;

import com.dlgds.steps.AbstractSteps;
import com.dlgds.utils.XMLUtil;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import org.w3c.dom.NodeList;

import java.text.ParseException;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class UWRulesSteps extends AbstractSteps {
    XMLUtil xmlUtil = new XMLUtil();

    @And("^modify (.+) request for driver age (.+)$")
    public void modifyRequestForDriverAge(String requestType, String data) throws Throwable {
        if (!data.contentEquals("none")) {
            String[] driversAndAge = data.split(";-");
            for (String driverAge : driversAndAge) {
                String[] nodeValue = driverAge.trim().split(" ");
                int age = Integer.parseInt(nodeValue[2].trim());
                String dob = LocalDate.now(Clock.systemUTC()).minusYears(age).format(dtf);
                String licenceDate = LocalDate.now(Clock.systemUTC()).minusYears(age).plusYears(20).format(dtf);
                setDriversAge(nodeValue[1], dob, licenceDate, requestType);
            }
        }
    }

    @And("^Inception date is Quote date (.+)$")
    public void inceptionDateIsEqualToEffectiveDate(int days) throws Throwable {
        String quoteDate = LocalDate.now(Clock.systemUTC()).format(dtf);
        String effectiveStartDate = LocalDate.now(Clock.systemUTC()).plusDays(days).format(dtf);
        String effectiveEndDate = LocalDate.now(Clock.systemUTC()).plusDays(days).plusYears(1).minusDays(1).format(dtf);

        xmlUtil.setAttributeForElements("Transaction:EffectiveDate:" + quoteDate);
        xmlUtil.setAttributeForElements("Policy_EffectiveStartDate:1:" + effectiveStartDate);
        xmlUtil.setAttributeForElements("Policy_EffectiveEndDate:1:" + effectiveEndDate);
        xmlUtil.setAttributeForElements("Policy_InceptionDate:1:" + effectiveStartDate);
    }

    @And("^Remove driver (\\d+) and add new driver$")
    public void removeDriverAndAddNewDriver(int driver) throws Throwable {
        xmlUtil.modifyNodes("Remove Driver:" + driver + " PolData:2");
        xmlUtil.setAttributeForElements("Driver_Prn:" + (driver + 2) + ":" + driver);
    }

    @And("^Remove claims & convictions from policy and set date on (.+) in MTA for (.+)$")
    public void setDateOfCcElementsForDrivers(String ccElement, String drivers) throws Throwable {
        xmlUtil.modifyNodes("Remove Incident:1 Driver:1 ;- Remove Incident:1 Driver:2");
        if (drivers.split(" ")[0].trim().contentEquals("3"))
            xmlUtil.modifyNodes("Remove Incident:1 Driver:3;-Remove Incident:1 Driver:4");
        if (!ccElement.toLowerCase().contentEquals("none")) {
            String[] claimConv = ccElement.trim().split(";-");
            String incidentDate = LocalDate.now(Clock.systemUTC()).minusDays(2).format(dtf);
            String setAttribute = claimConv[0].trim() + ":" + incidentDate;
            for (int i = 1; i < claimConv.length; i++) {
                setAttribute = setAttribute + ";- " + claimConv[i].trim() + ":" + incidentDate;
            }
            xmlUtil.setAttributeForElements(setAttribute);
        }
    }

    @And("^Set the (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+) and (.+) for (.+) with (.+)$")
    public void setTheValueAnd(String vehicleValue, String ownerShip, String keptON, String keptD, String hhCars, String dob,
                               String liType, String licenceDate, String residencyDate, String reqType, String drivers) throws Throwable {
        String noOfDrivers = drivers.trim().split(" ")[0].trim();
        switch (reqType.toLowerCase()) {
            case "mta":
                xmlUtil.setAttributeForElements("Vehicle_Value:2:" + vehicleValue + ";-Vehicle_Ownership:2:" + ownerShip);
                xmlUtil.setAttributeForElements("Vehicle_LocationKeptOvernight:2:" + keptON + ";-Vehicle_VehicleKeptDaytime:2:" + keptD);
                xmlUtil.setAttributeForElements("ProposerPolicyholder_NoOfVehiclesAvailableToFamily:2:" + hhCars);
                if (!dob.toLowerCase().contentEquals("none"))
                    xmlUtil.setAttributeForElements("Driver_DateOfBirth:" + (Integer.parseInt(noOfDrivers) + 2) + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_LicenceType:" + (Integer.parseInt(noOfDrivers) + 2) + ":" + liType);
                xmlUtil.setAttributeForElements("Driver_LicenceDate:" + (Integer.parseInt(noOfDrivers) + 2) + ":" + licenceDate);
                xmlUtil.setAttributeForElements("Driver_UkResidencyDate:" + (Integer.parseInt(noOfDrivers) + 2) + ":" + residencyDate);
                break;
            case "new business":
            case "cancellation":
                xmlUtil.setAttributeForElements("Vehicle_Value:1:" + vehicleValue + ";-Vehicle_Ownership:1:" + ownerShip);
                xmlUtil.setAttributeForElements("Vehicle_LocationKeptOvernight:1:" + keptON + ";-Vehicle_VehicleKeptDaytime:1:" + keptD);
                xmlUtil.setAttributeForElements("ProposerPolicyholder_NoOfVehiclesAvailableToFamily:1:" + hhCars);
                if (!dob.toLowerCase().contentEquals("none"))
                    xmlUtil.setAttributeForElements("Driver_DateOfBirth:" + noOfDrivers + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_LicenceType:" + noOfDrivers + ":" + liType);
                xmlUtil.setAttributeForElements("Driver_LicenceDate:" + noOfDrivers + ":" + licenceDate);
                xmlUtil.setAttributeForElements("Driver_UkResidencyDate:" + noOfDrivers + ":" + residencyDate);
                break;
        }
    }

    @And("^Set conviction date (.+) and ban period (.+) for (.+) in (.+)$")
    public void setConvictionDateMonthsInPastAndBanPeriodBanPeriodForDrivers(int monthsInPast, String banPeriod, String noOfDrivers, String requestType) throws Throwable {
        String convictionDate = LocalDate.now(Clock.systemUTC()).minusMonths(monthsInPast).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String driver = noOfDrivers.split(" ")[0].trim();
        if (requestType.toLowerCase().contains("conditional suppression")) {
            xmlUtil.setAttributeForElements("Conviction_Date:" + driver + ":" + convictionDate + ";-Conviction_SuspensionPeriod:" + driver + ":" + banPeriod + ";-Conviction_Date:" + (Integer.parseInt(driver) + 2) + ":" + convictionDate + ";-Conviction_SuspensionPeriod:" + (Integer.parseInt(driver) + 2) + ":" + banPeriod);
        } else {
            if (requestType.toLowerCase().contentEquals("mta")) {
                xmlUtil.modifyNodes("Remove Incident:1 Driver:1 ;- Remove Incident:1 Driver:2");
            }
            xmlUtil.setAttributeForElements("Conviction_Date:" + driver + ":" + convictionDate + ";-Conviction_SuspensionPeriod:" + driver + ":" + banPeriod);
        }
    }

    @And("^Set licence date (.+) for (.+) with (.+)$")
    public void setLicenceDateForNewBusiness(int yearsInPast, String requestType, String noOfDrivers) throws Throwable {
        String licenceDate = LocalDate.now(Clock.systemUTC()).minusYears(yearsInPast).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String driver = noOfDrivers.split(" ")[0];
        if (requestType.toLowerCase().contains("mta"))
            driver = String.valueOf(Integer.parseInt(driver) + 2);
        if (requestType.toLowerCase().contains("conditional supression"))
            xmlUtil.setAttributeForElements("Driver_LicenceDate:" + (Integer.parseInt(driver) - 2) + ":" + licenceDate + ";-Driver_LicenceDate:" + driver + ":" + licenceDate);
        else
            xmlUtil.setAttributeForElements("Driver_LicenceDate:" + driver + ":" + licenceDate);
    }

    @And("^Set manufacture year (.+) for (.+)$")
    public void setManufactureYearForNewBusiness(int yearsInPast, String requestType) throws Throwable {
        String manufactureYear = LocalDate.now(Clock.systemUTC()).minusYears(yearsInPast).format(DateTimeFormatter.ofPattern("yyyy"));
        String vehicle = "1";
        if (requestType.toLowerCase().contains("mta"))
            vehicle = String.valueOf(Integer.parseInt(vehicle) + 1);
        if (requestType.toLowerCase().contains("conditional supression"))
            xmlUtil.setAttributeForElements("Vehicle_YearManufactured:" + (Integer.parseInt(vehicle) - 1) + ":" + manufactureYear + ";-Vehicle_YearManufactured:" + vehicle + ":" + manufactureYear);
        else
            xmlUtil.setAttributeForElements("Vehicle_YearManufactured:" + vehicle + ":" + manufactureYear);
    }

    @And("^modify (.+) request for claim type (.+), date (.+) and ncd lost is (.+)$")
    public void modifyRequestForDriverAge(String requestType, String claimType, String yrsInPast, String ncdLost) throws Throwable {
        switch (requestType.toLowerCase()) {
            case "new business":
                if (!claimType.contentEquals("none")) {
                    xmlUtil.setAttributeOfNodes("Claim_ClaimType", 0, "Val", claimType);
                }
                if (!yrsInPast.contentEquals("none")) {
                    xmlUtil.setAttributeOfNodes("Claim_Date", 0, "Val", LocalDate.now(Clock.systemUTC()).minusYears(Integer.parseInt(yrsInPast)).format(dtf));
                }
                if (!ncdLost.contentEquals("none")) {
                    xmlUtil.setAttributeOfNodes("Claim_NcdLostInd", 0, "Val", ncdLost);
                }
                break;
            case "mta":
                if (!claimType.contentEquals("none")) {
                    xmlUtil.setAttributeOfNodes("Claim_ClaimType", 2, "Val", claimType);
                }
                if (!yrsInPast.contentEquals("none")) {
                    xmlUtil.setAttributeOfNodes("Claim_Date", 2, "Val", LocalDate.now(Clock.systemUTC()).minusYears(Integer.parseInt(yrsInPast)).format(dtf));
                }
                if (!ncdLost.contentEquals("none")) {
                    xmlUtil.setAttributeOfNodes("Claim_NcdLostInd", 2, "Val", ncdLost);
                }
                break;
        }
    }

    @And("^set Oldest or Youngest driver's age (.+) for (.+)$")
    public void setOldestDriverValues(String age, String requestType) throws Throwable {
        if (!age.contentEquals("none")) {
            String[] nodeValue = age.trim().split(" ");
            int years = Integer.parseInt(nodeValue[2].trim());
            String dob = LocalDate.now(Clock.systemUTC()).minusYears(years).format(dtf);
            String licenceDate = LocalDate.now(Clock.systemUTC()).minusYears(years).plusYears(20).format(dtf);
            String minusPlus;
            int days = 0;

            if (nodeValue.length == 7) {
                minusPlus = nodeValue[4].trim();
                days = Integer.parseInt(nodeValue[5].trim());
                switch (minusPlus) {
                    case "minus":
                        dob = LocalDate.now(Clock.systemUTC()).minusYears(years).plusDays(days).format(dtf);
                        licenceDate = LocalDate.now(Clock.systemUTC()).minusYears(years).plusDays(days).plusYears(20).format(dtf);
                        break;
                    case "plus":
                        dob = LocalDate.now(Clock.systemUTC()).minusYears(years).minusDays(days).format(dtf);
                        licenceDate = LocalDate.now(Clock.systemUTC()).minusYears(years).plusDays(days).plusYears(20).format(dtf);
                        break;
                }
            }
            setDriversAge(nodeValue[1], dob, licenceDate, requestType);
        }
    }

    public void setDriversAge(String driver, String dob, String licenceDate, String requestType) throws Throwable {
        switch (requestType.toLowerCase()) {
            case "new business":
                if (driver.contentEquals("1"))
                    xmlUtil.setAttributeForElements("ProposerPolicyholder_DateOfBirth:1:" + dob);
                xmlUtil.setAttributeForElements("Driver_DateOfBirth:" + Integer.parseInt(driver) + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_UkResidencyDate:" + Integer.parseInt(driver) + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_LicenceDate:" + Integer.parseInt(driver) + ":" + licenceDate);
                break;
            case "mta":
                if (driver.contentEquals("1"))
                    xmlUtil.setAttributeForElements("ProposerPolicyholder_DateOfBirth:2:" + dob);
                xmlUtil.setAttributeForElements("Driver_DateOfBirth:" + (Integer.parseInt(driver) + 2) + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_UkResidencyDate:" + (Integer.parseInt(driver) + 2) + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_LicenceDate:" + (Integer.parseInt(driver) + 2) + ":" + licenceDate);
                break;
            case "mta: conditional suppression":
            default:
                if (driver.contentEquals("1")) {
                    xmlUtil.setAttributeForElements("ProposerPolicyholder_DateOfBirth:1:" + dob);
                    xmlUtil.setAttributeForElements("ProposerPolicyholder_DateOfBirth:2:" + dob);
                }
                xmlUtil.setAttributeForElements("Driver_DateOfBirth:" + (Integer.parseInt(driver)) + ":" + dob + ";-Driver_DateOfBirth:" + (Integer.parseInt(driver) + 2) + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_UkResidencyDate:" + (Integer.parseInt(driver)) + ":" + dob + ";-Driver_UkResidencyDate:" + (Integer.parseInt(driver) + 2) + ":" + dob);
                xmlUtil.setAttributeForElements("Driver_LicenceDate:" + (Integer.parseInt(driver)) + ":" + licenceDate + ";-Driver_LicenceDate:" + (Integer.parseInt(driver) + 2) + ":" + licenceDate);
                break;
        }
    }
}
