package com.dlgds.Helperfiles_Testing;

import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class xmlToElements {

    public static void main(String[] args) {
        try {
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = db.parse(new File("/Users/preetam/Tech/Automation/functional-scenarios/src/test/resources/cdl_example_private_car_new_business_response.xml"));
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer t = tf.newTransformer();
            StringWriter sw = new StringWriter();
            t.transform(new DOMSource(document), new StreamResult(sw));
            String request = sw.toString();

            String xsl = "<xsl:stylesheet version=\"1.0\"  xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">\n" +
                    "    <xsl:output omit-xml-declaration=\"yes\" indent=\"yes\"/>\n" +
                    "    <xsl:strip-space elements=\"*\"/>\n" +
                    "\n" +
                    "    <xsl:variable name=\"vApos\">'</xsl:variable>\n" +
                    "\n" +
                    "    <xsl:template match=\"*[@* or not(*)] \">\n" +
                    "      <xsl:if test=\"not(*)\">\n" +
                    "         <xsl:apply-templates select=\"ancestor-or-self::*\" mode=\"path\"/>\n" +
                    "         <xsl:value-of select=\"concat('=',$vApos,.,$vApos)\"/>\n" +
                    "         <xsl:text>&#xA;</xsl:text>\n" +
                    "        </xsl:if>\n" +
                    "        <xsl:apply-templates select=\"@*|*\"/>\n" +
                    "    </xsl:template>\n" +
                    "\n" +
                    "    <xsl:template match=\"*\" mode=\"path\">\n" +
                    "        <xsl:value-of select=\"concat('/',name())\"/>\n" +
                    "        <xsl:variable name=\"vnumPrecSiblings\" select=\n" +
                    "         \"count(preceding-sibling::*[name()=name(current())])\"/>\n" +
                    "        <xsl:if test=\"$vnumPrecSiblings\">\n" +
                    "            <xsl:value-of select=\"concat('[', $vnumPrecSiblings +1, ']')\"/>\n" +
                    "        </xsl:if>\n" +
                    "    </xsl:template>\n" +
                    "\n" +
                    "    <xsl:template match=\"@*\">\n" +
                    "        <xsl:apply-templates select=\"../ancestor-or-self::*\" mode=\"path\"/>\n" +
                    "        <xsl:value-of select=\"concat('[@',name(), '=',$vApos,.,$vApos,']')\"/>\n" +
                    "        <xsl:text>&#xA;</xsl:text>\n" +
                    "    </xsl:template>\n" +
                    "</xsl:stylesheet>";
            // Create transformer factory
            TransformerFactory factory = TransformerFactory.newInstance();

            // Use the factory to create a template containing the xsl file
            Templates template = factory.newTemplates(new StreamSource(
                    new StringReader(xsl)));

            // Use the template to create a transformer
            Transformer xformer = template.newTransformer();

            // Prepare the input and output files
            Source source = new StreamSource(new StringReader(request));
            Result result = new StreamResult(new StringWriter());
//            System.out.println(result);

            // Apply the xsl file to the source file and write the result
            // to the output file
            xformer.transform(source, result);
            String transformedXpaths = ((StreamResult) result).getWriter().toString();
            //System.out.println("----------------------------------------------------------- \n" + ((StreamResult) result).getWriter().toString());
            //System.out.println(xpaths);
            String[] individualXpaths = transformedXpaths.split(System.getProperty("line.separator"));
            ArrayList<String> xpaths = new ArrayList<>();
            List<String> names = new ArrayList<>();

            for (String xpa : individualXpaths) {
                xpa = xpa.replace("/s11:Envelope/s11:Body/pr:", "/").replace("/pmq:", "/").replace("/mddr:", ".");
                //System.out.println(xpath);
                xpa = xpa.substring(0, xpa.lastIndexOf("="));
                //System.out.println(xpa);
                xpaths.add(xpa);
                names.add(xpa.substring(xpa.lastIndexOf("/") + 1, xpa.length()));
            }

//            for (int i = 0; i < xpaths.size(); i++) {
//                System.out.println(xpaths.get(i));
//                System.out.println(names.get(i));
//            }

            ArrayList<String> uniqueNames = new ArrayList<>();
            for (int i = 0; i < names.size(); i++) {
                String name = "";

                if (Collections.frequency(names, names.get(i)) > 1) {
//                    System.out.println(names.get(i));
                    String xpath = xpaths.get(i);
                    xpath = xpath.substring(0, xpath.lastIndexOf("/")) + xpath.substring(xpath.lastIndexOf("/") + 1, xpath.length());
                    name = xpath.substring(xpath.lastIndexOf("/") + 1, xpath.length());
                    uniqueNames.add(name);
                } else {
                    uniqueNames.add(names.get(i));
                }
            }

            for (int i = 0; i < xpaths.size(); i++) {
//                System.out.println("----------- " + xpaths.get(i));
//                System.out.println("-----------" + uniqueNames.get(i));
//                if (!uniqueNames.get(i).contains("[@Val"))
//                    System.out.println("XmlElementPath.put(\""+uniqueNames.get(i)+"\",\""+xpaths.get(i)+"\");");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}