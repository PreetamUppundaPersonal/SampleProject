package com.dlgds.Helperfiles_Testing;

import jlibs.xml.sax.XMLDocument;
import jlibs.xml.xsd.XSInstance;
import jlibs.xml.xsd.XSParser;
import org.apache.xerces.xs.XSConstants;
import org.apache.xerces.xs.XSModel;
import org.apache.xerces.xs.XSNamedMap;
import org.w3c.dom.Document;

import javax.xml.XMLConstants;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.StringWriter;

public class XsdToXml {
    public static void main(String[] Args) throws Throwable {
        File[] samplexsd = new File("/Users/preetam/Tech/Automation/functional-scenarios/src/test/resources/com.dlgds.Helperfiles_Testing.testDirectory/").listFiles();

        //Create resulting folder
        if(!new File("SampleXML").exists()) new File("SampleXML").mkdir();

        DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document = db.parse(samplexsd[1]);
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer();
        StringWriter sw = new StringWriter();
        t.transform(new DOMSource(document), new StreamResult(sw));
        String xsdString = sw.toString();

        XSModel xsModelString = new XSParser().parseString(xsdString, "");
        //Default options
        XSInstance instance = new XSInstance();
        instance.minimumElementsGenerated = 0;
        instance.maximumElementsGenerated = 3;
        instance.generateDefaultAttributes = false;
        instance.generateOptionalAttributes = false;
        instance.maximumRecursionDepth = 0;
        instance.generateOptionalElements = true;

        XSNamedMap map = xsModelString.getComponents(XSConstants.ELEMENT_DECLARATION);
        QName rootElement = new QName(map.item(0).getNamespace(), map.item(0).getName(), XMLConstants.DEFAULT_NS_PREFIX);
//        System.out.println(rootElement);

        for (int i = 0; i < samplexsd.length; i++) {
            if(samplexsd[i].isFile() && samplexsd[i].getName().contains("xsd")) { //Eliminate directories and make sure is a schema
                XSModel xsModel = new XSParser().parse(samplexsd[i].getAbsolutePath());
                //Name the result
                XMLDocument sample = new XMLDocument(new StreamResult("SampleXML/" + samplexsd[i].getName().substring(0, samplexsd[i].getName().indexOf(".")) + ".xml"), false, 4, null);

                try {
                    instance.generate(xsModel, rootElement, sample);
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                }
            }
        }
//        System.out.println("Done --- check your the SampleXML folder");
    }
}
